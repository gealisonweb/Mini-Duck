package dev.cru.browser;

import java.net.IDN;
import java.net.URI;
import java.net.URLEncoder;
import java.util.Locale;

/** Small, pure-Java policy shared by navigation and host-side checks. */
final class NavigationPolicy {
    static final String[] ENGINES = {"Google", "DuckDuckGo", "Bing"};
    private static final String[] SEARCH = {
        "https://www.google.com/search?q=", "https://duckduckgo.com/?q=", "https://www.bing.com/search?q="
    };
    private static final String[] TRACKERS = {
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "google-analytics.com", "googletagmanager.com"
    };

    static String input(String value) {
        return input(value, 0);
    }

    static String input(String value, int engine) {
        String raw = value == null ? "" : value.trim();
        if (raw.isEmpty()) throw new IllegalArgumentException("Digite um endereço ou uma busca.");
        if (raw.length() > 8192 || raw.matches("(?s).*\\p{Cntrl}.*"))
            throw new IllegalArgumentException("Endereço muito longo ou inválido.");
        boolean explicit = raw.matches("(?i)^https?://.*");
        if (!explicit && raw.matches("(?i)^[a-z][a-z0-9+.-]*:.*")
                && !raw.matches("[^/\\s:]+:[0-9]+(?:[/?#].*)?"))
            throw new IllegalArgumentException("Use um endereço HTTPS.");
        if (explicit || (!raw.matches("(?s).*\\s.*") && raw.split("[/?#]", 2)[0].contains("."))) {
            return https(explicit ? raw : "https://" + raw);
        }
        try { return SEARCH[engine >= 0 && engine < SEARCH.length ? engine : 0] + URLEncoder.encode(raw, "UTF-8"); }
        catch (java.io.UnsupportedEncodingException e) { throw new AssertionError(e); }
    }

    static String https(String raw) {
        try {
            if (raw == null || raw.length() > 8192 || raw.matches("(?s).*\\p{Cntrl}.*")) throw new Exception();
            URI uri = new URI(raw);
            String scheme = uri.getScheme();
            if (!"https".equalsIgnoreCase(scheme) && !"http".equalsIgnoreCase(scheme)) throw new Exception();
            String authority = uri.getRawAuthority();
            if (authority == null || authority.contains("@") || authority.contains("\\") || authority.contains("%")) throw new Exception();
            String host = authority;
            String port = "";
            if (host.startsWith("[")) {
                int close = host.indexOf(']');
                if (close < 0 || uri.getHost() == null) throw new Exception();
                port = host.substring(close + 1);
                host = host.substring(0, close + 1);
            } else {
                int colon = host.lastIndexOf(':');
                if (colon >= 0) { port = host.substring(colon); host = host.substring(0, colon); }
                host = IDN.toASCII(host, IDN.USE_STD3_ASCII_RULES).toLowerCase(Locale.ROOT);
                if (host.isEmpty()) throw new Exception();
            }
            if (!port.isEmpty()) {
                if (!port.matches(":[0-9]{1,5}")) throw new Exception();
                int number = Integer.parseInt(port.substring(1));
                if (number < 1 || number > 65535) throw new Exception();
            }
            String path = uri.getRawPath();
            String result = "https://" + host + port + (path == null || path.isEmpty() ? "/" : path);
            if (uri.getRawQuery() != null) result += "?" + uri.getRawQuery();
            if (uri.getRawFragment() != null) result += "#" + uri.getRawFragment();
            return new URI(result).toASCIIString();
        } catch (Exception e) {
            throw new IllegalArgumentException("Endereço inválido. Use HTTPS sem usuário ou senha na URL.");
        }
    }

    static boolean blocked(String host) {
        if (host == null) return false;
        String h = host.toLowerCase(Locale.ROOT);
        while (h.endsWith(".")) h = h.substring(0, h.length() - 1);
        for (String rule : TRACKERS) {
            if (h.equals(rule) || (h.length() > rule.length()
                    && h.charAt(h.length() - rule.length() - 1) == '.' && h.endsWith(rule))) return true;
        }
        return false;
    }

    private NavigationPolicy() { }
}
