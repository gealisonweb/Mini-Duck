package dev.cru.browser;
import android.app.Activity;
import android.app.DownloadManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.webkit.*;
public final class MainActivity extends Activity {
    private static final String AMOLED_SCRIPT = "(function(){"
            + "if(!/(^|\\.)duckduckgo\\.com$/.test(location.hostname))return;"
            + "document.documentElement.style.colorScheme='dark';"
            + "document.querySelectorAll('html,body,body :not(img):not(svg):not(path)').forEach(function(el){"
            + "el.style.setProperty('background-color','#000','important');"
            + "el.style.setProperty('color',el.closest('a')?'#a8c7fa':'#eee','important');"
            + "el.style.setProperty('border-color','#555','important');});})()";
    private WebView page;
    public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
        page = new WebView(this);
        page.setBackgroundColor(android.graphics.Color.BLACK);
        WebSettings s = page.getSettings();
        s.setJavaScriptEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(true);
        page.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                String host = Uri.parse(url).getHost();
                if (view == page && ("duckduckgo.com".equals(host)
                        || (host != null && host.endsWith(".duckduckgo.com")))) {
                    view.evaluateJavascript(AMOLED_SCRIPT, null);
                }
            }
        });
        page.setDownloadListener((url, userAgent, disposition, type, size) -> {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setMimeType(type);
            request.addRequestHeader("User-Agent", userAgent);
            request.setTitle(URLUtil.guessFileName(url, disposition, type));
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                    URLUtil.guessFileName(url, disposition, type));
            ((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(request);
        });
        setContentView(page);
        page.loadUrl("https://html.duckduckgo.com/html/");
    }
    protected void onPause() {
        if (page != null) { page.stopLoading(); page.onPause(); page.pauseTimers(); }
        super.onPause();
    }
    protected void onResume() {
        super.onResume();
        if (page != null) { page.onResume(); page.resumeTimers(); }
    }
    protected void onStop() {
        super.onStop();
        CookieManager.getInstance().removeAllCookies(null);
        WebStorage.getInstance().deleteAllData();
        discard();
        finishAndRemoveTask();
    }
    public void onBackPressed() {
        if (page != null && page.canGoBack()) page.goBack();
        else super.onBackPressed();
    }
    private void discard() {
        if (page == null) return;
        page.stopLoading();
        page.clearCache(true);
        page.clearHistory();
        page.clearFormData();
        android.view.ViewParent parent = page.getParent();
        if (parent instanceof android.view.ViewGroup) ((android.view.ViewGroup)parent).removeView(page);
        page.destroy();
        page = null;
    }
    protected void onDestroy() { discard(); super.onDestroy(); }
}
