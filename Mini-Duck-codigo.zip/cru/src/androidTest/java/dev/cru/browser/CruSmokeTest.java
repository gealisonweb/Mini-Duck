package dev.cru.browser;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.EditText;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/** Real WebView/lifecycle checks against this new package only; no user's existing browser data. */
public final class CruSmokeTest extends Instrumentation {
    private Activity activity;
    private ActivityMonitor monitor;
    private final String fixture = "<!doctype html><meta name=viewport content='width=device-width'>"
            + "<body style='font:20px sans-serif;padding:20px'><h1>CRU: teste</h1>"
            + "<p id=result>sem-js</p><input aria-label='Formulario' value='campo editavel'>"
            + "<script>document.getElementById('result').textContent='js-ok';</script></body>";

    @Override public void onCreate(Bundle args) { super.onCreate(args); start(); }

    @Override public void onStart() {
        Bundle result = new Bundle();
        int resultCode = Activity.RESULT_CANCELED;
        try {
            PackageInfo info = getTargetContext().getPackageManager().getPackageInfo("dev.cru.browser", 4096);
            require(info.requestedPermissions != null && info.requestedPermissions.length == 1
                    && "android.permission.INTERNET".equals(info.requestedPermissions[0]), "Unexpected permissions");
            Intent launch = new Intent(Intent.ACTION_MAIN).setClassName("dev.cru.browser", "dev.cru.browser.MainActivity")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            monitor = addMonitor("dev.cru.browser.MainActivity", null, false);
            activity = startActivitySync(launch);
            waitForIdleSync();
            require(page() == null, "Home must not create a WebView");
            screenshot("home");
            result.putString("home", "PASS: native home, no WebView");

            navigate("example.org");
            awaitPage();
            String body = javascript("document.body ? document.body.innerText : ''");
            require(body.length() > 80 && javascript("location.protocol + '//' + location.host").contains("https://example.org"),
                    "HTTPS response did not display visible content");
            result.putString("https", "PASS: example.org rendered over HTTPS");
            inspectCompatibleSettings();
            loadFixture();
            require(javascript("document.getElementById('result').textContent").contains("js-ok"), "Normal mode must execute page JS");
            inspectInterception();
            screenshot("compatible");
            result.putString("compatible", "PASS: JavaScript, editable form, filter boundaries and HTTPS policy");

            backgroundAndResume();
            require(page() == null, "Resume must not automatically recreate the page");
            result.putString("background", "PASS: page destroyed in background; resume remains native");
            navigate("example.org");
            awaitPage();
            inspectCompatibleSettings();
            backgroundAndResume();
            require(page() == null, "Page must also be destroyed when hidden");
            result.putString("stream", "PASS: CRU smoke test\n" + result);
            resultCode = Activity.RESULT_OK;
        } catch (Throwable e) {
            screenshot("failure");
            result.putString("stream", "FAIL: " + e + "\n" + result);
        } finally {
            if (activity != null && !activity.isDestroyed()) ui(() -> activity.finishAndRemoveTask());
            if (monitor != null) removeMonitor(monitor);
        }
        finish(resultCode, result);
    }

    private void inspectCompatibleSettings() {
        ui(() -> {
            WebView view = find(activity.getWindow().getDecorView(), WebView.class);
            WebSettings s = view.getSettings();
            require(s.getJavaScriptEnabled() && s.getLoadsImagesAutomatically(), "Compatibility defaults missing");
            require(!s.getAllowFileAccess() && !s.getAllowContentAccess(), "Local file access must stay disabled");
            require(s.getMediaPlaybackRequiresUserGesture(), "Autoplay must require a gesture");
            require(s.getMixedContentMode() == WebSettings.MIXED_CONTENT_NEVER_ALLOW, "Mixed content must be blocked");
            require(view.getRendererPriorityWaivedWhenNotVisible(), "Hidden renderer must be reclaimable");
            require(count(activity.getWindow().getDecorView(), WebView.class) == 1, "Only one WebView is allowed");
        });
    }

    private void inspectInterception() {
        ui(() -> {
            WebView view = find(activity.getWindow().getDecorView(), WebView.class);
            WebResourceResponse blocked = view.getWebViewClient().shouldInterceptRequest(view, request("https://ads.doubleclick.net/pixel", false));
            require(blocked != null, "Known tracker not blocked");
            require(view.getWebViewClient().shouldInterceptRequest(view, request("https://example.org/site.css", false)) == null, "Normal resource blocked");
            require(view.getWebViewClient().shouldInterceptRequest(view, request("https://doubleclick.net/", true)) == null, "Main frame unexpectedly filtered");
            require(view.getWebViewClient().shouldOverrideUrlLoading(view, request("file:///sdcard/test.html", true)), "File navigation accepted");
        });
    }

    private void loadFixture() {
        ui(() -> find(activity.getWindow().getDecorView(), WebView.class)
                .loadDataWithBaseURL("https://cru-test.example/", fixture, "text/html", "UTF-8", null));
        awaitPage();
    }

    private void navigate(String value) {
        ui(() -> {
            EditText edit = find(activity.getWindow().getDecorView(), EditText.class);
            edit.setText(value);
            edit.onEditorAction(EditorInfo.IME_ACTION_GO);
        });
    }

    private WebView page() {
        AtomicReference<WebView> result = new AtomicReference<>();
        ui(() -> result.set(find(activity.getWindow().getDecorView(), WebView.class)));
        return result.get();
    }

    private void awaitPage() {
        long deadline = SystemClock.elapsedRealtime() + 30000;
        while (SystemClock.elapsedRealtime() < deadline) {
            boolean[] done = {false};
            ui(() -> {
                WebView view = find(activity.getWindow().getDecorView(), WebView.class);
                done[0] = view != null && view.getProgress() == 100 && view.getContentHeight() > 0 && view.isShown();
            });
            if (done[0]) { SystemClock.sleep(200); return; }
            SystemClock.sleep(200);
        }
        throw new AssertionError("Page did not render within 30 seconds");
    }

    private String javascript(String code) throws InterruptedException {
        AtomicReference<String> result = new AtomicReference<>("");
        CountDownLatch done = new CountDownLatch(1);
        ui(() -> find(activity.getWindow().getDecorView(), WebView.class).evaluateJavascript(code, value -> { result.set(value); done.countDown(); }));
        require(done.await(5, TimeUnit.SECONDS), "JavaScript callback missing");
        return result.get();
    }

    private void backgroundAndResume() {
        ui(() -> activity.moveTaskToBack(true));
        SystemClock.sleep(800);
        boolean[] destroyed = {false};
        ui(() -> destroyed[0] = activity.isDestroyed());
        require(destroyed[0], "Hidden browser activity must finish");
        require(page() == null, "Hidden page was not destroyed");
        getTargetContext().startActivity(new Intent(Intent.ACTION_MAIN)
                .setClassName("dev.cru.browser", "dev.cru.browser.MainActivity")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
        long deadline = SystemClock.elapsedRealtime() + 5000;
        while (SystemClock.elapsedRealtime() < deadline) {
            SystemClock.sleep(200);
            waitForIdleSync();
            Activity latest = monitor.getLastActivity();
            if (latest != null) activity = latest;
            boolean[] visible = {false};
            ui(() -> visible[0] = !activity.isDestroyed() && activity.getWindow().getDecorView().hasWindowFocus());
            if (visible[0]) return;
        }
        throw new AssertionError("Activity did not return to foreground");
    }

    private void ui(Runnable action) {
        AtomicReference<Throwable> failure = new AtomicReference<>();
        runOnMainSync(() -> { try { action.run(); } catch (Throwable e) { failure.set(e); } });
        if (failure.get() != null) throw new AssertionError("UI check failed", failure.get());
    }

    private void clickText(String text) {
        SystemClock.sleep(300);
        AccessibilityNodeInfo root = getUiAutomation().getRootInActiveWindow();
        require(root != null, "Accessibility root missing");
        List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByText(text);
        for (AccessibilityNodeInfo node : nodes) {
            if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) { SystemClock.sleep(300); return; }
        }
        throw new AssertionError("Menu item not clickable: " + text);
    }

    private void screenshot(String label) {
        try {
            Bitmap bitmap = getUiAutomation().takeScreenshot();
            if (bitmap == null) return;
            File file = new File(getTargetContext().getExternalFilesDir(null), "cru-" + label + ".png");
            try (FileOutputStream out = new FileOutputStream(file)) { bitmap.compress(Bitmap.CompressFormat.PNG, 100, out); }
            bitmap.recycle();
        } catch (Exception ignored) { }
    }

    private static WebResourceRequest request(String value, boolean main) {
        return new WebResourceRequest() {
            public Uri getUrl() { return Uri.parse(value); }
            public boolean isForMainFrame() { return main; }
            public boolean isRedirect() { return false; }
            public boolean hasGesture() { return true; }
            public String getMethod() { return "GET"; }
            public Map<String, String> getRequestHeaders() { return Collections.emptyMap(); }
        };
    }

    private static void require(boolean condition, String message) { if (!condition) throw new AssertionError(message); }

    private static <T extends View> T find(View root, Class<T> type) {
        if (type.isInstance(root)) return type.cast(root);
        if (root instanceof ViewGroup) {
            ViewGroup group = (ViewGroup)root;
            for (int n = 0; n < group.getChildCount(); n++) { T found = find(group.getChildAt(n), type); if (found != null) return found; }
        }
        return null;
    }

    private static View described(View root, String description) {
        if (description.contentEquals(root.getContentDescription() == null ? "" : root.getContentDescription())) return root;
        if (root instanceof ViewGroup) {
            ViewGroup group = (ViewGroup)root;
            for (int n = 0; n < group.getChildCount(); n++) { View found = described(group.getChildAt(n), description); if (found != null) return found; }
        }
        return null;
    }

    private static int count(View root, Class<? extends View> type) {
        int result = type.isInstance(root) ? 1 : 0;
        if (root instanceof ViewGroup) {
            ViewGroup group = (ViewGroup)root;
            for (int n = 0; n < group.getChildCount(); n++) result += count(group.getChildAt(n), type);
        }
        return result;
    }
}
